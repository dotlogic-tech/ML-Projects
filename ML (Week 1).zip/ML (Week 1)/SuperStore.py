import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

class SuperstoreAnalyzer:
    """
    Encapsulates the analysis and visualization of the Superstore dataset.
    """
    # Class attribute for consistent month ordering
    MONTHS_ORDER = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ]

    def __init__(self, file_path, encoding='latin1'):
        """
        Initializes the analyzer by loading and preparing the dataset.
        """
        self.df = pd.read_csv(file_path, encoding=encoding).dropna()
        self.df['Order Date'] = pd.to_datetime(self.df['Order Date'])
        self.df['Ship Date'] = pd.to_datetime(self.df['Ship Date'])

    def perform_text_analysis(self):
        """
        Performs and prints basic descriptive and profit analysis to the console.
        """
        print("--- Basic & Profit Analysis ---")
        print(self.df.describe(include='all'))
        print(f"\nUnique customers: {self.df['Customer ID'].nunique()}")
        print(f"\nTop 5 product counts:\n{self.df['Product ID'].value_counts().head()}")
        print("\nYearly profit:")
        print(self.df.resample('YE', on='Order Date')['Profit'].sum())
        print("\nHighly unprofitable orders (< -$1000):")
        print(self.df[self.df['Profit'] < -1000])
        print("\n" + "-"*30 + "\n")

    def plot_trends(self):
        """
        Plots yearly profit and monthly sales trends.
        """
        # Yearly Profit Trend
        self.df.resample('YE', on='Order Date')['Profit'].sum().plot(title='Yearly Profit Trends')
        plt.ylabel("Profit ($)")
        plt.tight_layout()
        plt.show()
        # Monthly Sales Trend
        monthly_sales = self.df.groupby(self.df['Order Date'].dt.month_name())['Sales'].sum()
        monthly_sales.reindex(self.MONTHS_ORDER).plot(
            marker='o', color='purple', title="Monthly Sales Trends"
        )
        plt.ylabel("Sales ($)")
        plt.xlabel("Month")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()

    def plot_distributions(self):
        """
        Plots heatmaps and bar charts for sales and shipment distributions.
        """
        # Heatmap: Sales by Region & Category
        pivot = self.df.pivot_table(values='Sales', index='Region', columns='Category', aggfunc='sum')
        plt.figure(figsize=(10, 6))
        sns.heatmap(pivot, annot=True, fmt=".0f", cmap="YlGnBu", linewidths=.5)
        plt.title("Sales by Region & Category")
        plt.tight_layout()
        plt.savefig('sales_heatmap.png')
        plt.show()
        # Bar Chart: Sales by Category
        self.df.groupby('Category')['Sales'].sum().sort_values().plot(kind='bar')
        plt.title('Sales by Category')
        plt.ylabel("Sales ($)")
        plt.tight_layout()
        plt.savefig('sales_by_category.png')
        plt.show()
        # Bar Chart: Orders by Ship Month
        ship_counts = self.df['Ship Date'].dt.month_name().value_counts()
        ship_counts.reindex(self.MONTHS_ORDER).plot(
            kind='bar', color='skyblue', title='Number of Orders by Ship Month'
        )
        plt.ylabel('Number of Orders')
        plt.xlabel('Month')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('orders_by_ship_month.png', dpi=400, bbox_inches='tight')
        plt.show()

    def plot_3d_scatter(self):
        """
        Creates an interactive 3D scatter plot of Sales vs. Profit vs. Quantity.
      """
        px.scatter_3d(
            self.df, x='Sales', y='Profit', z='Quantity', color='Category',
            title='Superstore: Sales vs Profit vs Quantity',
            labels={'Sales': 'Sales ($)', 'Profit': 'Profit ($)', 'Quantity': 'Quantity Sold'},
            width=800, height=600
        ).show()

    def run_full_analysis(self):
        """
        Executes all analysis and plotting methods in sequence.
        """
        self.perform_text_analysis()
        self.plot_trends()
        self.plot_distributions()
        self.plot_3d_scatter()
        
if __name__ == "__main__":
    # Provide the path to your data file
    FILE_PATH = r"D:\ML (Week 1)\Superstore.csv"
    # Create an instance of the analyzer and run the analysis
    analyzer = SuperstoreAnalyzer(FILE_PATH)
    analyzer.run_full_analysis()
    