import streamlit as st
import pandas as pd
import joblib
import os

# Load model with caching
@st.cache_resource
def load_model():
    return joblib.load("models/best_model.pkl")

model = load_model()

# ----- Page Settings -----
st.set_page_config(page_title="Loan Approval App", layout="centered")
st.title("🏦 Loan Approval Prediction System")
st.markdown("Use the form below to check if a loan will be approved based on applicant details.")

# ----- Sidebar -----
st.sidebar.image("https://cdn-icons-png.flaticon.com/512/2331/2331970.png", width=80)
st.sidebar.header("💡 How it works")
st.sidebar.markdown("""
1. Enter applicant details on the left.
2. Click **Predict**.
3. You'll get an approval result & prediction probability.
""")
st.sidebar.success("Model: Random Forest Classifier")

# ----- Form for Input -----
with st.form("loan_form"):
    st.subheader("📝 Applicant Details")

    col1, col2 = st.columns(2)
    with col1:
        gender = st.selectbox("Gender", ["Male", "Female"])
        married = st.selectbox("Married", ["Yes", "No"])
        dependents = st.selectbox("Dependents", ["0", "1", "2", "3+"])
        education = st.selectbox("Education", ["Graduate", "Not Graduate"])
        self_employed = st.selectbox("Self Employed", ["Yes", "No"])
    with col2:
        applicant_income = st.number_input("Applicant Income", min_value=0)
        coapplicant_income = st.number_input("Coapplicant Income", min_value=0)
        loan_amount = st.number_input("Loan Amount", min_value=0)
        loan_term = st.number_input("Loan Amount Term (days)", min_value=0)
        credit_history = st.selectbox("Credit History", [1.0, 0.0])
        property_area = st.selectbox("Property Area", ["Urban", "Rural", "Semiurban"])

    submitted = st.form_submit_button("🔍 Predict Loan Approval")

# ----- On Predict -----
if submitted:
    # Encode inputs
    input_data = {
        'Gender': 1 if gender == "Male" else 0,
        'Married': 1 if married == "Yes" else 0,
        'Dependents': {'0': 0, '1': 1, '2': 2, '3+': 3}[dependents],
        'Education': 1 if education == "Graduate" else 0,
        'Self_Employed': 1 if self_employed == "Yes" else 0,
        'ApplicantIncome': applicant_income,
        'CoapplicantIncome': coapplicant_income,
        'LoanAmount': loan_amount,
        'Loan_Amount_Term': loan_term,
        'Credit_History': credit_history,
        'Property_Area': {'Urban': 2, 'Rural': 0, 'Semiurban': 1}[property_area]
    }

    input_df = pd.DataFrame([input_data])

    # Predict and show result
    prediction = model.predict(input_df)[0]
    prob = model.predict_proba(input_df)[0][prediction]

    # Result
    if prediction == 1:
        st.success(f"✅ Loan Approved (Confidence: {prob:.2%})")
    else:
        st.error(f"❌ Loan Rejected (Confidence: {prob:.2%})")

    # Summary table
    with st.expander("📋 View Submitted Details"):
        st.write(input_df)

    # Save prediction to CSV
    result_row = input_df.copy()
    result_row["Prediction"] = "Approved" if prediction == 1 else "Rejected"
    if not os.path.exists("prediction_logs.csv"):
        result_row.to_csv("prediction_logs.csv", index=False)
    else:
        result_row.to_csv("prediction_logs.csv", mode="a", header=False, index=False)

    st.success("Prediction saved to `prediction_logs.csv` ✅")
