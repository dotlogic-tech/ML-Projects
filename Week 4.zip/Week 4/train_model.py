import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import joblib
import os

# Load the dataset
df = pd.read_csv("data/Loan_Pred.csv")

# Create synthetic target variable
# Simple rule: if credit history is 1 and income > 5000, approve
df['Loan_Status'] = ((df['Credit_History'] == 1.0) & (df['ApplicantIncome'] > 5000)).astype(int)

# Drop rows with missing values
df.dropna(inplace=True)

# Encode categorical variables
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
for col in df.select_dtypes(include='object').columns:
    df[col] = le.fit_transform(df[col])

# Define features and target
X = df.drop(["Loan_ID", "Loan_Status"], axis=1)

y = df["Loan_Status"]

# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# Train the model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print("Model Evaluation:\n", classification_report(y_test, y_pred))

# Save the model
os.makedirs("models", exist_ok=True)
joblib.dump(model, "models/best_model.pkl")
print("Model trained and saved to models/best_model.pkl")

