import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# Load the dataset
data = pd.read_csv('Mall_Customers.csv')

# Display basic information about the dataset
print("Dataset Information:")
print(data.info())
print("\nFirst 5 rows:")
print(data.head())

# Select relevant features for clustering
features = data[['Age', 'Annual Income (k$)', 'Spending Score (1-100)']]
X = features.values

# Feature scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Determine optimal number of clusters using Elbow method
wcss = []
silhouette_scores = []
cluster_range = range(2, 6)  # As per project suggestion of 3-5 groups

for k in cluster_range:
    kmeans = KMeans(n_clusters=k, init='k-means++', random_state=42)
    kmeans.fit(X_scaled)
    wcss.append(kmeans.inertia_)
    silhouette_scores.append(silhouette_score(X_scaled, kmeans.labels_))

# Plot Elbow method
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(cluster_range, wcss, marker='o')
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.grid()

# Plot Silhouette scores
plt.subplot(1, 2, 2)
plt.plot(cluster_range, silhouette_scores, marker='o')
plt.title('Silhouette Scores')
plt.xlabel('Number of clusters')
plt.ylabel('Silhouette Score')
plt.grid()

plt.tight_layout()
plt.show()

# Based on the plots, let's choose 5 clusters as it shows good balance
optimal_clusters = 5
kmeans = KMeans(n_clusters=optimal_clusters, init='k-means++', random_state=42)
clusters = kmeans.fit_predict(X_scaled)

# Add cluster labels to the original data
data['Cluster'] = clusters

# Visualize clusters in 2D using PCA
pca = PCA(n_components=2)
principal_components = pca.fit_transform(X_scaled)
principal_df = pd.DataFrame(data=principal_components, columns=['PC1', 'PC2'])
principal_df['Cluster'] = clusters

plt.figure(figsize=(10, 8))
for cluster in range(optimal_clusters):
    plt.scatter(principal_df.loc[principal_df['Cluster'] == cluster, 'PC1'],
                principal_df.loc[principal_df['Cluster'] == cluster, 'PC2'],
                label=f'Cluster {cluster}', alpha=0.7)

plt.title('Customer Segments (PCA-reduced space)')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.legend()
plt.grid()
plt.show()

# Visualize clusters using original features (Annual Income vs Spending Score)
plt.figure(figsize=(10, 8))
for cluster in range(optimal_clusters):
    plt.scatter(data.loc[data['Cluster'] == cluster, 'Annual Income (k$)'],
                data.loc[data['Cluster'] == cluster, 'Spending Score (1-100)'],
                label=f'Cluster {cluster}', alpha=0.7)

plt.title('Customer Segments (Income vs Spending Score)')
plt.xlabel('Annual Income (k$)')
plt.ylabel('Spending Score (1-100)')
plt.legend()
plt.grid()
plt.show()

# Visualize clusters using original features (Age vs Spending Score)
plt.figure(figsize=(10, 8))
for cluster in range(optimal_clusters):
    plt.scatter(data.loc[data['Cluster'] == cluster, 'Age'],
                data.loc[data['Cluster'] == cluster, 'Spending Score (1-100)'],
                label=f'Cluster {cluster}', alpha=0.7)

plt.title('Customer Segments (Age vs Spending Score)')
plt.xlabel('Age')
plt.ylabel('Spending Score (1-100)')
plt.legend()
plt.grid()
plt.show()

# Analyze and describe each cluster
cluster_profiles = data.groupby('Cluster').agg({
    'Age': 'mean',
    'Annual Income (k$)': 'mean',
    'Spending Score (1-100)': 'mean',
    'CustomerID': 'count'
}).rename(columns={'CustomerID': 'Count'})

print("\nCluster Profiles:")
print(cluster_profiles)

# Describe each customer segment
print("\nCustomer Segment Descriptions:")
segments = {
    0: "Young, low income, high spenders - These are young customers with below-average income but high spending habits. They might be students or early-career individuals who prioritize spending.",
    1: "Middle-aged, average income and spending - This group represents the average customer in terms of age, income, and spending. They are likely established professionals with balanced spending habits.",
    2: "Older, low income, low spenders - These are older customers with limited income and conservative spending patterns, possibly retirees on fixed incomes.",
    3: "Young, high income, high spenders - Affluent young professionals or successful entrepreneurs who have both high income and high spending capacity.",
    4: "Middle-aged, high income, low spenders - High-earning individuals who are more conservative with their spending, possibly saving for future goals."
}

for cluster, description in segments.items():
    print(f"\nCluster {cluster}: {description}")
    print(f"Average age: {cluster_profiles.loc[cluster, 'Age']:.1f} years")
    print(f"Average income: ${cluster_profiles.loc[cluster, 'Annual Income (k$)']:.1f}k")
    print(f"Average spending score: {cluster_profiles.loc[cluster, 'Spending Score (1-100)']:.1f}")