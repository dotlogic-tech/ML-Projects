#
# Student Performance Predictor - A binary classification model with visualizations
#
# This script has been corrected to prevent a blank figure from appearing in the output.
# The code now uses a more explicit method for creating and displaying the plots,
# ensuring only the intended visualizations are shown.
#
# Libraries used:
# - pandas for data manipulation
# - scikit-learn for machine learning models and evaluation metrics
# - matplotlib for plotting the visualizations
#

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

print("--- Student Performance Predictor with Visualizations ---")

# --- 1. Load and Prepare the Dataset ---
# Now loading the local file named 'StudentsPerformance.csv'
try:
    student_data = pd.read_csv('StudentsPerformance.csv')
    print("Local dataset 'StudentsPerformance.csv' loaded successfully.")
except FileNotFoundError:
    print("Error: 'StudentsPerformance.csv' not found. Please ensure the file is in the same directory.")
    print("Exiting script.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred: {e}")
    print("Exiting script.")
    exit()

# --- 2. Define the Target Variable ---
student_data['average score'] = student_data[['math score', 'reading score', 'writing score']].mean(axis=1)
student_data['Pass'] = student_data['average score'].apply(lambda x: 1 if x >= 60 else 0)

student_data.drop(['math score', 'reading score', 'writing score', 'average score'], axis=1, inplace=True)

# --- 3. Feature Engineering (Categorical to Numerical) ---
features = student_data.drop('Pass', axis=1)
target = student_data['Pass']
features = pd.get_dummies(features, drop_first=True)

# --- 4. Split the Data ---
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

print("\nData Split into Training and Testing Sets:")
print(f"Training set size: {X_train.shape[0]} samples")
print(f"Testing set size: {X_test.shape[0]} samples")

# --- 5. Train and Evaluate Models ---
def evaluate_model(model_name, model, X_train, y_train, X_test, y_test):
    """
    Trains and evaluates a given model, printing key metrics and
    displaying a confusion matrix heatmap.
    """
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    conf_matrix = confusion_matrix(y_test, y_pred)

    print(f"\n--- Model: {model_name} ---")
    print(f"Accuracy: {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print("Confusion Matrix:")
    print(conf_matrix)
    print("     Predicted: Fail Pass")
    print(f"Actual Fail:    {conf_matrix[0, 0]}    {conf_matrix[0, 1]}")
    print(f"Actual Pass:    {conf_matrix[1, 0]}    {conf_matrix[1, 1]}")
    print("-----------------------------------")
    
    # --- Confusion Matrix Visualization (Heatmap) ---
    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay.from_predictions(y_test, y_pred, 
                                          display_labels=['Fail', 'Pass'],
                                          cmap='Blues', ax=ax)
    ax.set_title(f"{model_name} - Confusion Matrix")
    fig.tight_layout()
    plt.show()

    return model

# Train and evaluate the Logistic Regression model
logistic_regression_model = evaluate_model("Logistic Regression", LogisticRegression(random_state=42), X_train, y_train, X_test, y_test)

# Train and evaluate the Decision Tree model
decision_tree_model = evaluate_model("Decision Tree", DecisionTreeClassifier(random_state=42), X_train, y_train, X_test, y_test)

# --- 6. Explain How Features Affect Performance and Visualize ---
print("\n--- Feature Importance from Decision Tree Model ---")
feature_importances = decision_tree_model.feature_importances_
feature_names = features.columns
sorted_indices = feature_importances.argsort()[::-1]

for i in sorted_indices:
    print(f"{feature_names[i]}: {feature_importances[i]:.4f}")

# --- Feature Importance Visualization ---
# Create the DataFrame first
df_importance = pd.DataFrame({'Feature': features.columns, 
                              'Importance': decision_tree_model.feature_importances_}).sort_values('Importance', ascending=False)
# Create a figure and axes, then plot directly to the axes
fig, ax = plt.subplots(figsize=(10, 6))
df_importance.plot.barh(x='Feature', y='Importance', legend=False, ax=ax)
ax.set_title("Feature Importance in Decision Tree")
ax.set_xlabel("Relative Importance")
fig.tight_layout()
plt.show()